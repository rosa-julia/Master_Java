
package DTO;

public class ControleBairroDTO extends DadosBasicosDTO{
    
}
