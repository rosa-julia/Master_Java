
package INTER;


public interface DadosBasicosINTER {
    int getId();
    int getBairro();
    String getNome();
    String getSenha();
    
    void setId(int id);
    void setBairro(int bairro);
    void setNome(String nome);
    void setSenha(String senha);
    
    
}
